// Simple alias so routes can import "@/auth/Login".
// This component immediately redirects to Auth0 Universal Login.

import SSOLogin from "./SSOLogin";

export default SSOLogin;
